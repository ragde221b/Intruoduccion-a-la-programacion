#include <iostream>
#include <string.h>
#include <stdlib.h>

char linea[20];
char fecha[8];
char e[2]="/";
char f[2]="\0";
char *token;
int num[10],i;

int main(int argc, char** argv) {
	printf("Ingrese la fecha en formato dd/mm/aa");
	gets(fecha);
	i=0;
	token=strtok(fecha,e);
	num[i]=atoi(token);i++;
	while ((token=strtok(NULL,e)) !=NULL ){
		num[i]=atoi(token);
		i++;
	}
	if(num[0]>00&&num[0]<32){
		printf("%d\t",num[0]);
	}
	if(num[1]>00&&num[1]<13){
		switch(num[1]){
			case 1:
				printf("Enero\t");
			break;
			case 2:
				printf("Febrero\t");
			break;
			case 3:
				printf("Marzo\t");
			break;
			case 4:
				printf("Abril\t");
			break;
			case 5:
				printf("Mayo\t");
			break;
			case 6:
				printf("Junio\t");
			break;
			case 7:
				printf("Julio\t");
			break;
			case 8:
				printf("Agosto\t");
			break;
			case 9:
				printf("Septiembre\t");
			break;
			case 10:
				printf("Octubre\t");
			break;
			case 11:
				printf("Noviembre\t");
			break;
			case 12:
				printf("Diciembre\t");
			break;
		}
	}
	if(num[2]>=00&&num[2]<=18){
		if(num[2]<=10){
			printf("200%d",num[2]);
		}
		else{
			printf("20%d",num[2]);
		}
	}
	if(num[2]>18){
		printf("19%d",num[2]);
	}
	
	return 0;
}
