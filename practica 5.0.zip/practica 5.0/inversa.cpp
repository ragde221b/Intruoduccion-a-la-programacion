#include <iostream>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


int main(int argc, char *argv[]) {
	char frase[100];
	char e[2]=" ";
	char *frac=strtok(frase,e);
	char texto[15];
	int i,j;
	
	printf("Introducir texto\n");
	scanf("%50[^\n]", frase);
    printf("\nIngresaste: %s \n",frase);
	i=strlen(frase);
	for(j=i-1;j>=0;j--){ 
		printf("%c",frase[j]);
	}
	printf("\n");

	return 0;
}
