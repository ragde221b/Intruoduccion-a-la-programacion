#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int cant_mesas(int a);
int ocupar_mesas(int t_mesas[],int a);
int menu(int opc);

int main(int argc, char** argv) {
	int a;
	a=cant_mesas(a);
	int t_mesas[a];
	system("cls");
	int opc;
	menu(opc);
	switch (opc){
		case 1:
			ocupar_mesas(t_mesas,a);
		break;
	}
	
	
	//printf("El numero total de mesas es %d",a);
	return 0;
}

int cant_mesas(int a){
	printf("Ingrese el numero total de mesas:\t");
	scanf("%d",&a);
	return a;
}

int ocupar_mesas(int t_mesas[],int a){
	int num_mesa;
	int i=0;
	printf("Ingrese el numero de la mesa que se acaba de ocupar");
	scanf("%d",&num_mesa);
	do{
		if(t_mesas[i]==0){
			t_mesas[i]=num_mesa;
		}
		i++;
	}
	while(t_mesas[i]!=0 || i<a);
	if(i>=a){
		printf("El lugar se encuentra lleno");
		i=0;
	}
	return ocupar_mesas[a];
}

int menu(int opc){
	printf("1.-\tIngresar mesa\n2.-\tAgregar a la cuenta\n3.-\tRegistrar pago\n");
	printf("Ingrese la accion a realizar:");
	scanf("%d",&opc);
	return opc;
}
