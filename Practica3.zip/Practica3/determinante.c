#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int x,y,tamano,a[y][x]={};
	printf("seleccione el tamano de su matriz");
	scanf("%d",&tamano);
	for(y=0;y<=tamano;y++){
		for(x=0;x<=tamano;x++){
			printf("Ingrese el valor %d %d",x,y);
			scanf("%d",&a[y][x]);
		}
	}
	for(y=0;y<=tamano;y++){
		for(x=0;x<=tamano;x++){
			printf("%d",a[y][x]);
		}
	}
	
	return 0;
}
