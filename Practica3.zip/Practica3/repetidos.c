#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int arr[10],i,c;
	for(i=0;i<=9;i++){
		printf("Ingrese el valor %d\t ",i+1);
		scanf("%d",&arr[i]);
	}
	for(i=9;i>=0;i--){
		c=i-1;
		for(c=c;c>=0;c--){
			if(arr[i]==arr[c]){
				arr[i]=0;
			}
		}
	}
	for(i=0;i<=9;i++){
		printf("%d\t",arr[i]);
	}
	return 0;
}
