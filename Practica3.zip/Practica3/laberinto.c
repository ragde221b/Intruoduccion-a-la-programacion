#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int lab[5][6]={1,2,1,1,0,0,
	1,0,1,1,0,1,
	1,0,1,1,0,1,
	1,0,0,0,0,1,
	1,1,0,1,1,1};
	int y,x;
	int posx;
	int posy;
	char boton;
	char inst[]="Para moverse en el laberinto presione:\na para la izquierda\nd para la derecha\nspara abajo\nwpara arriba";
	char no[]="El movimiento que desea no es posible de realizar, por favor intente otra vez";
	for(y=0;y<=4;y++){
		for(x=0;x<=5;x++){
			printf("%d\t",lab[y][x]);
		}
		printf("\n");
	}
	do{
		printf("\n%s \n",inst);
		for(y=0;y<=4;y++){
			for(x=0;x<=5;x++){
				if(lab[y][x]>1){
					posx=x;
					posy=y;
				}
			}
		}
		scanf("%s",&boton);
		switch(boton){
				case 'a':
					if(lab[posy][posx-1]==1){
						printf("%s\n",no);
						system("pause");
					}
					else{
						lab[posy][posx]=0;
						lab[posy][posx-1]=2;
					}
				break;
				case 's':
					if(lab[posy+1][posx]==1){
						printf("%s\n",no);
						system("pause");
					}
					else{
						lab[posy][posx]=0;
						lab[posy+1][posx]=2;
					}
				break;
				case 'd':
					if(lab[posy][posx+1]==1){
						printf("%s\n",no);
						system("pause");
					}
					else{
						lab[posy][posx]=0;
						lab[posy][posx+1]=2;
					}
				break;
				case 'w':
					if(lab[posy-1][posx]==1){
						printf("%s\n",no);
						system("pause");
					}
					else{
						lab[posy][posx]=0;
						lab[posy-1][posx]=2;
					}
				break;
		}
		system("cls");
		for(y=0;y<=4;y++){
			for(x=0;x<=5;x++){
				printf("%d\t",lab[y][x]);
			}
			printf("\n");
		}
	}
	while(lab[0][5]==0);
	printf("Felicidades, usted ha acabado el laberinto");
	return 0;
}
