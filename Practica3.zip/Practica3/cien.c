#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int arr[100],cont[10]={0},i,n;
	srand(time(NULL));
	for(i=0;i<=99;i++){
		arr[i]=1+rand()%10;
		switch(arr[i]){
			case 1:
				cont[0]++;
			break;
			case 2:
				cont[1]++;
			break;
			case 3:
				cont[2]++;
			break;
			case 4:
				cont[3]++;
			break;
			case 5:
				cont[4]++;
			break;
			case 6:
				cont[5]++;
			break;
			case 7:
				cont[6]++;
			break;
			case 8:
				cont[7]++;
			break;
			case 9:
				cont[8]++;
			break;
			case 10:
				cont[9]++;
			break;
		}
	}
	for(i=0;i<=99;i++){
		printf("%d|",arr[i]);
	}
	printf("\n");
	printf("\nFrecuencia de valores:\nnumero\tfrecuencia\n");
	for(i=0;i<=9;i++){
		n=i+1;
		printf("%d\t%d\n",n,cont[i]);
	}
	
	system ("pause");
	return 0;
}
