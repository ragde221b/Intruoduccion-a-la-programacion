#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a[10],x,y,aux;
	srand(time(NULL));
	printf("Introduce los elementos de tu arreglo\n");
	for(x=0;x<10;x++){
		//scanf("%d",&a[x]);
		a[x]=-10000+rand()%((10000+1)-(-10000));
		printf("%d\t",a[x]);
	}
	for(y=0;y<9;y++){
	for(x=0;x<9;x++){
		if(a[x]>a[x+1]){
			aux=a[x];
			a[x]=a[x+1];
			a[x+1]=aux;
		}
	}
	}
	printf("\n\nLos valores en orden de menor a mayor son:\n");
	for(x=0;x<10;x++){
		printf("%d\t",a[x]);
	}
	system("pause");
	return 0;
}
