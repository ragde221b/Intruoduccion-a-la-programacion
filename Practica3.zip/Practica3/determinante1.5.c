#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MAX 20
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int determinante(int a[][MAX],int tamano);
int cofactor(int a[][MAX],int tamano,int fila,int columna);

int tamano,i,j;
int a[MAX][MAX];
int main(int argc, char *argv[]) {
	printf("seleccione el tamano de su matriz");
	scanf("%d",&tamano);
	for(j=0;j<tamano;j++){
		for(i=0;i<tamano;i++){
			printf("Ingrese el valor %d %d\t",j,i);
			scanf("%d",&a[j][i]);
		}
	}
	for(j=0;j<tamano;j++){
		for(i=0;i<tamano;i++){
			printf("%d\t",a[j][i]);
		}
		printf("\n");
	}
	printf("El determinante es %d\n",determinante(a,tamano));
	return 0;
}
int determinante(int a[][MAX],int tamano){
	int det=0;
	if(tamano==1){
		det=a[0][0];
	}
	else{
		for(i=0;i<tamano;i++){
			det+=a[0][i]*cofactor(a,tamano,0,i);
		}
	}
	return det;
}
int cofactor(int a[][MAX],int tamano,int fila,int columna){
	int suba[MAX][MAX];
	int n=tamano-1,x=0,y=0;
	for(j=0;j<tamano;j++){
		for(i=0;i<tamano;i++){
			if(j!=fila && i!=columna){
				suba[x][y]=a[j][i];
				y++;
				if(y>=n){
					x++;
					y=0;
				}
			}
		}
	}
	return pow(-i,fila+columna) * determinante(suba,n);
}
