#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int estado[10][12]={
	90,90,40,60,20,80,10,10,30,70,50,25,                //Sonora
	100,80,50,10,60,40,100,40,80,70,100,56,             //Aguas Calientes
	70,90,60,20,80,50,20,60,30,70,110,60,               //Oaxaca
	50,60,50,30,20,80,50,40,20,70,200,70,               //Colima
	90,90,60,40,80,70,60,40,30,50,10,40,                //Chihuahua
	40,10,50,40,30,90,30,80,80,60,90,86,                //San Luis Potosi
	100,40,20,50,10,100,90,80,100,70,130,120,           //Durango
	70,10,90,70,50,30,70,60,20,50,40,89,                //Veracruz
	40,30,40,70,10,100,20,20,70,20,90,66,               //Yucatan
	10,60,100,50,60,40,50,100,90,20,15,30};             //Tabasco
	int sumf[10]={0};
	char max[]={};
	int x,y,i,j,MAX,MIN,mes=0;
	int ac[12];
	for(y=0;y<=9;y++){
		for(x=0;x<=11;x++){
			printf("%d\t",estado[y][x]);	//y estado; x mes
		}
		printf("\n");
	}
	for(y=0;y<=9;y++){
		for(x=0;x<=11;x++){
				sumf[y]+=estado[y][x];
		}
	}
	printf("\n\n");
	for(y=0;y<=9;y++){
		if(sumf[y]>MAX){
			MAX=sumf[y];
		}
	}
	MIN=sumf[9];
	for(y=9;y>=0;y--){
		if(sumf[y]<MIN){
			MIN=sumf[y];
		}
	}	
	//printf("\n%d\n%d\n",MAX,MIN);
	y=0;
	do{
		y++;
	}
	while(MAX!=sumf[y]);
	switch(y){
			case 0:
				printf("Sonora\n");
			break;
			case 1:
				printf("Aguas Calientes\n");
			break;
			case 2:
				printf("Oaxaca\n");
			break;
			case 3:
				printf("Colima\n");
			break;
			case 4:
				printf("Chihuahua\n");
			break;
			case 5:
				printf("San Luis Potosi\n");
			break;
			case 6:
				printf("Durango\n");
			break;
			case 7:
				printf("Veracruz\n");
			break;
			case 8:
				printf("Yucatan\n");
			break;
			case 9:
				printf("Tabasco\n");
			break;
		}
	x=0;
	do{
        y++;
 }
	while(MIN!=sumf[x]);
	switch(x){
			case 0:
				printf("Sonora\n");
			break;
			case 1:
				printf("Aguas Calientes\n");
			break;
			case 2:
				printf("Oaxaca\n");
			break;
			case 3:
				printf("Colima\n");
			break;
			case 4:
				printf("Chihuahua\n");
			break;
			case 5:
				printf("San Luis Potosi\n");
			break;
			case 6:
				printf("Durango\n");
			break;
			case 7:
				printf("Veracruz\n");
			break;
			case 8:
				printf("Yucatan\n");
			break;
			case 9:
				printf("Tabasco\n");
			break;
		}
	for(x=0;x<=11;x++){
                       ac[x]=estado[1][x];
}
    for(x=0;x<=11;x++){
                       if(ac[x]>mes){
                                     mes=ac[x];
                       }
}
	for(x=0;x<=11;x++){
          if(mes==ac[x]){
               switch (x){
                      case 0:
                           printf("Enero\n");
                      break;
                      case 1:
                           printf("Febrero\n");
                      break;
                      case 2:
                           printf("Marzo\n");
                      break;
                      case 3:
                           printf("Ablil\n");
                      break;
                      case 4:
                           printf("Mayo\n");
                      break;
                      case 5:
                           printf("Junio\n");
                      break;
                      case 6:
                           printf("Julio\n");
                      break;
                      case 7:
                           printf("Agosto\n");
                      break;
                      case 8:
                           printf("Septiembre\n");
                      break;
                      case 9:
                           printf("Octubre\n");
                      break;
                      case 10:
                           printf("Noviembre\n");
                      break;
                      case 11:
                           printf("Diciembre\n");
                      break;
                      
               }
          }
}
	
	
    system("pause");
	return 0;
}
