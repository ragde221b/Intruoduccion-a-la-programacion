#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int ma[3][3];
	int a,b;
	for(a=0;a<3;a++){
		for(b=0;b<3;b++){
			printf("Introduce el valor de ");
			scanf("%d",&ma[a][b]);
		}
	}
	printf("La inverza de la matriz es...:\n");
	for(a=0;a<3;a++){
		for(b=0;b<3;b++){
			printf("%d\t",ma[b][a]);
		}
		printf("\n");
	}
	return 0;
}
