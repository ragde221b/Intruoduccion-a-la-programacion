#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int i,j,tamano,det_a,b;
	printf("seleccione el tamano de su matriz");
	scanf("%d",&tamano);
	int a[tamano][tamano];
	b=tamano-1;
	int menor[b][b];
	for(j=0;j<tamano;j++){
		for(i=0;i<tamano;i++){
			printf("Ingrese el valor %d %d\t",j,i);
			scanf("%d",&a[j][i]);
		}
	}
	for(j=0;j<tamano;j++){
		for(i=0;i<tamano;i++){
			printf("%d\t",a[j][i]);
		}
		printf("\n");
	}
	for(j=0;j<b;j++){
		for(i=0;i<b;i++){
			menor[j][i]=a[j+1][i+1];
		}
	}
	printf("\n");
	for(j=0;j<b;j++){
		for(i=0;i<b;i++){
			printf("%d\t",menor[j][i]);
		}
		printf("\n");
	}
	/*for(i=0;i<tamano;i++){
		det_a+=(pow(-1,i+1))*((a[0][i]))
	}
	switch(tamano){
		case 2:
			det_a=((a[0][0])*(a[1][1]))-((a[0][1])*(a[1][0]));
		break;
		case 3:
			det_a=((a[0][0])*(((a[1][1])*(a[2][2]))-((a[2][1])*(a[1][2]))));
		break;
	}*/
	//printf("%d",det_a);
	return 0;
}
