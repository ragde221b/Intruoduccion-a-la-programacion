#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

void inicio();
void arreglo();
void muestra();
void ingreso();
void simulacion();
void letra();
void letra2();
	
int f,c,i,a,num,x,y;
char let,matriz[20][20];

int main(int argc, char *argv[]) {
	inicio();
	arreglo();
	muestra();
	ingreso();
	
	for(y=0;y<=30;y++){
	simulacion();
	muestra();
	printf("\n\t\t\t\tSimulando...\n\t\t\t\tA=Alarma de la oficina\n\t\t\t\tR=Rociador");
	Sleep(500);
	arreglo();
	muestra();
	printf("\n\t\t\t\tSimulando...\n\t\t\t\tA=Alarma de la oficina\n\t\t\t\tR=Rociador");
	Sleep(500);
	}
	muestra();
	printf("\n\t\t\t\tEl fuego se ha apagado");
	
	return 0;
}

void inicio(){
	system("cls");
	printf("\t\tA continuacion indique el numero de oficinas que hay, indicandolas por filas y columnas.\n");
	
	filas:
	printf("\t\t\t\t   Filas: "); scanf("%i",&f);
	if(f>10){
		printf("Este es un valor muy grande, prueba con un valor menor a 10\n");
		goto filas;
	}
	
	columnas:
	printf("\t\t\t\tColumnas: "); scanf("%i",&c);
	if(c>10){
		printf("Este es un valor muy grande, prueba con un valor menor a 10\n");
		goto columnas;
	}		
}

void arreglo(){
	//char matriz[f+f+1][c+c+1];
	//Escribe los bordes en la matriz 
	for(i=0;i<=(f+f);i++){
		for(a=0;a<=(c+c);a++){
			matriz[i][a]=' ';
		}
	}
	
	for(i=0;i<=(f+f);i=i+2){
		for(a=0;a<=(c+c);a++){
			matriz[i][a]='+';
		}
	}
	
	for(i=0;i<=(f+f);i++){
		for(a=0;a<=(c+c);a=a+2){
			matriz[i][a]='+';
		}
	}
}

void muestra(){
	//Muestra en la pantalla
	system("cls");
	printf("\n\n");
	printf("\t\t\t\t  ");
	for(i=1;i<=c;i++){
		printf("%i   ",i);
	}
	printf("\n");
	for(i=0;i<=(f+f);i++){	
		if(i%2!=0){
			printf("\t\t\t    ");
			letra();
		}
		else{
			printf("\t\t\t\t");
		}
		for(a=0;a<=(c+c);a++){
			printf("%c ",matriz[i][a]);
		}
		printf("\n");
	}
}

void ingreso(){
	printf("Que oficina se esta quemando?\nEscriba la coordenada.\n");
	letra:
	printf("\t\t\t Letra: ");
	fflush( stdin );
	scanf("%c",&let);
	letra2();
	if(x>f){
		printf("La letra no es valida, vuelva a ingresarla\n");
		goto letra;
	}
	numero:
	printf("\t\t\tNumero: ");
	fflush( stdin );
	scanf("%i",&num);
	if(num>c){
		printf("El numero no es valido, vuelva a ingresarlo\n");
		goto numero;
	}
}

void simulacion(){
	
	if(matriz[x+x-1][num+num-1]==' '){
		matriz[x+x-1][num+num-1]='R';	//rociador principal
	}	
	if(matriz[x+x-1+2][num+num-1]==' '){
		matriz[x+x-1+2][num+num-1]='R'; //rociador de abajo 
	}
	if(matriz[x+x-1-2][num+num-1]==' '){
		matriz[x+x-1-2][num+num-1]='R'; //rociador de arriba 
	}
	if(matriz[x+x-1][num+num-1+2]==' '){
		matriz[x+x-1][num+num-1+2]='R'; //rociador derecha 
	}
	if(matriz[x+x-1][num+num-1-2]==' '){
		matriz[x+x-1][num+num-1-2]='R'; //rociador izquierda 
	}
	if(matriz[x+x-1+2][num+num-1-2]==' '){
		matriz[x+x-1+2][num+num-1-2]='R'; //rociador inferior izquierdo
	}
	if(matriz[x+x-1+2][num+num-1+2]==' '){
		matriz[x+x-1+2][num+num-1+2]='R'; //rociador inferior derecho
	}
	if(matriz[x+x-1-2][num+num-1-2]==' '){
		matriz[x+x-1-2][num+num-1-2]='R'; //rociador superior izquierdo
	}
	if(matriz[x+x-1-2][num+num-1+2]==' '){
		matriz[x+x-1-2][num+num-1+2]='R'; //rociador superior derecho
	}
	if(matriz[x+x-1][num+num-1-4]==' '){
		matriz[x+x-1][num+num-1-4]='A';	//Alarma izq principal
	}
	if(matriz[x+x-1+2][num+num-1-4]==' '){
		matriz[x+x-1+2][num+num-1-4]='A';	//Alarma izq-abajo
	}
	if(matriz[x+x-1-2][num+num-1-4]==' '){
		matriz[x+x-1-2][num+num-1-4]='A';	//Alarma izq-arriba
	}
	if(matriz[x+x-1][num+num-1+4]==' '){
		matriz[x+x-1][num+num-1+4]='A';	//Alarma der principal
	}
	if(matriz[x+x-1-2][num+num-1+4]==' '){
		matriz[x+x-1-2][num+num-1+4]='A';	//Alarma der-arriba
	}
	if(matriz[x+x-1+2][num+num-1+4]==' '){
		matriz[x+x-1+2][num+num-1+4]='A';	//Alarma der-abajo
	}
	if(matriz[x+x-1-4][num+num-1]==' '){
		matriz[x+x-1-4][num+num-1]='A';	//Alarma up principal
	}
	if(matriz[x+x-1-4][num+num-1-2]==' '){
		matriz[x+x-1-4][num+num-1-2]='A';	//Alarma up-izq
	}
	if(matriz[x+x-1-4][num+num-1+2]==' '){
		matriz[x+x-1-4][num+num-1+2]='A';	//Alarma up-der
	}
	if(matriz[x+x-1+4][num+num-1]==' '){
		matriz[x+x-1+4][num+num-1]='A';	//Alarma abajo principal
	}
	if(matriz[x+x-1+4][num+num-1-2]==' '){
		matriz[x+x-1+4][num+num-1-2]='A';	//Alarma abajo-izq
	}
	if(matriz[x+x-1+4][num+num-1+2]==' '){
		matriz[x+x-1+4][num+num-1+2]='A';	//Alarma abajo-der
	}
}

void letra(){
	switch(i){
		case 0: break;
		case 1: printf("A   "); break;
		case 2: break;
		case 3: printf("B   "); break;
		case 4: break;
		case 5: printf("C   "); break;
		case 6: break;
		case 7: printf("D   "); break;
		case 8: break;
		case 9: printf("E   "); break;
		case 10: break;
		case 11: printf("F   "); break;
		case 12: break;
		case 13: printf("G   "); break;
		case 14: break;
		case 15: printf("H   "); break;
		case 16: break;
		case 17: printf("I   "); break;
		case 18: break;
		case 19: printf("J   "); break;
		
	}
}

void letra2(){
	switch(let){
		case 'a': 
		case 'A': x=1; break;
		case 'b': 
		case 'B': x=2; break;
		case 'c': 
		case 'C': x=3; break;
		case 'd': 
		case 'D': x=4; break;
		case 'e': 
		case 'E': x=5; break;
		case 'f': 
		case 'F': x=6; break;
		case 'g': 
		case 'G': x=7; break;
		case 'h': 
		case 'H': x=8; break;
		case 'i': 
		case 'I': x=9; break;
		case 'j': 
		case 'J': x=10; break;
	}
}
