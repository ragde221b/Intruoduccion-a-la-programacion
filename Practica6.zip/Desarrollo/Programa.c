#include <stdio.h>
#include <stdlib.h>

void fun1(int *arr1);
void fun2(int *arr1, int *arr2, int *arr3);
void fun3(int *arr1, int *arr4);
void fun4(int *arr1, char *arr5);

int main(int argc, char *argv[]){
	int arreglo1[]={4,0,9,4,0},arreglo2[]={3,6,4,3,7},arreglo3[5],arreglo4[5],i;
	char arreglo5[5];
	int *arr1,*arr2,*arr3,*arr4;
	char *arr5;
	char div[]="-------------------------------";
	arr1=&arreglo1;
	arr2=&arreglo2;
	arr3=&arreglo3;
	arr4=&arreglo4;
	arr5=&arreglo5;
	fun1(arr1);
	fun2(arr1,arr2,arr3);
	for(i=0;i<5;i++){
		printf("%d\t",arr3[i]);			 
	} 
	printf("\n%s\n",div);
	fun3(arr1,arr4);
	fun4(arr1,arr5);
	for(i=0;i<5;i++){
		printf("%c\t",arr5[i]);
	}
	printf("\n%s\n",div);
	system("PAUSE");	
	return 0;
}
void fun1(int *arr1){
	int i;
	char div[]="-------------------------------";
	printf("Funcion i:\n");
	for(i=0;i<5;i++){
 		printf("%d\t",arr1[i]);
		} 	 
	printf("\n%s\n",div); 
}

void fun2(int *arr1, int *arr2, int *arr3){
	int i,res;
	printf("Funcion ii:\nArreglo original:\n");
	for(i=0;i<5;i++){
		printf("%d\t",arr1[i]);				 
	} 	
	printf("\nArreglo No. 2:\n");
	for(i=0;i<5;i++){
		printf("%d\t",arr2[i]);				 
	} 
	printf("\nSuma de los dos arreglos:\n");
 	for(i=0;i<5;i++){
		arr3[i]=arr1[i]+arr2[i];			 
	} 	 
}

void fun3(int *arr1, int *arr4){
	int i;
	char div[]="-------------------------------";
	printf("Funcion iii:\nArreglo original:\n"); 
	for(i=0;i<5;i++){
		printf("%d\t",arr1[i]);
		arr4[4-i]=arr1[i];			 
	} 	
	printf("\nArreglo invertido:\n");
	for(i=0;i<5;i++){
 		printf("%d\t",arr1[4-i]); 				 
	}	 
	printf("\n%s\n",div);
}

void fun4(int *arr1, char *arr5){
	int i;
	printf("Funcion iv:\nArreglo original:\n");
	for(i=0;i<5;i++){
		printf("%d\t",arr1[i]);				 
	} 
	printf("\nArreglo par o impar:\n");
 	for(i=0;i<5;i++){
		if(arr1[i]%2==0){
			arr5[i]='P';			  
		} 			
		else{
			arr5[i]='I'; 	  
		}	 
	}	
}
