#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int x,y,a,b,r;
  printf("\n\n\t Ingrese el valor de x");
  scanf("%d",&x);
  printf("\n\n\t Ingrese el valor de y");
  scanf("%d",&y);
  printf("\n\n\t Ingrese el valor de a");
  scanf("%d",&a);
  printf("\n\n\t Ingrese el valor de b");
  scanf("%d",&b);
  r=((x+y)*(x+y))*(a-b);
  printf(" el resultado de la expresion (x+y)^2(a+b)=%d",r);
  
  system("PAUSE");	
  return 0;
}
