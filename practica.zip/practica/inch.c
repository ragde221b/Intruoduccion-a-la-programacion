#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float ft,yrd,inch,cm,m;
  printf("\n\tIngrese el valor de la medida que desea convertir en pies:\n\t");
  scanf("%f",&ft);
  inch=12*ft;
  yrd=ft/3;
  cm=inch*2.54;
  m=cm/100;
  printf("\n\tEl valor convertido a:\n\tpulgadas es:\t%f\n\tyardas es:\t%f\n\tcentimetros es:\t%f\n\tmetros es:\t%f\n\t",inch,yrd,cm,m);
  
  system("PAUSE");	
  return 0;
}
