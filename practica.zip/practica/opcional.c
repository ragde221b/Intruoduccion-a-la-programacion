#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float i,r,v;
  printf("ingrese el vlor de la corriente y del voltaje");
  scanf("%f %f",&i,&v);
  r=v/i;
  printf("%f",r);
  
  system("PAUSE");	
  return 0;
}
