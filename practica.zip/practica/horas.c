#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int h,minutos,st,segundos;
  printf("Ingrese el vaor en segundos:");
  scanf("%d",&st);
  h=st/60<60?0:st/3600;
  minutos=h<0?st/60:(st/60)%60;
  segundos=st%60;
  
  printf("%i %i %d",h,minutos,segundos);
  system("PAUSE");	
  return 0;
}
