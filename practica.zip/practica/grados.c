#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int g;
  float r;
  char letra,we;
  printf("ingrese valor que desea convertir");
  scanf("%i %c",&g,&letra);
  r=(letra=='c')?((9*g)/5)+32:((g-32)*5)/9;
  we=(letra=='c')?'f':'c';
  printf("%f %c",r,we);
  
  
  system("PAUSE");	
  return 0;
}
