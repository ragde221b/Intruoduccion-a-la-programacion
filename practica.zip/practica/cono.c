#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[])
{
  float r,h,g,v,a;
  printf("\n\tIngrese el valor del radio y la altura\n\t");
  scanf("%f %f",&r,&h);
  //g=pow(r,2)+(pow(h,2));
  //g=sqrt(g);
  g=_hypot(r,h);
  v=(M_PI*pow(r,2)*h)/3;
  a=(M_PI*r)*(g+r);
  printf("\n\tEl valor del volumen es:%f\n\tEl valor del area es:%f",v,a);
  
  
  system("PAUSE");	
  return 0;
}
