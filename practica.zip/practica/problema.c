#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define g 9.81

int main(int argc, char *argv[])
{
  char fluido;
  float v,h,d,p,p1,a;
  printf("ingese a para carcular agua y d para diesel");
  scanf("%c",&fluido);
  printf("ingrese el valor del fluido a calcular");
  scanf("%f",&p);
  printf("ingrese el valor del diametro");
  scanf("%f",&d);
  p1=(fluido=='a')?1000:820;
  h=p/(p1*g);
  a=pow(d/2,2)*M_PI;
  v=a*h;
  printf("el volumen que ocupa el fluido es:%f",v);
  
  
  system("PAUSE");	
  return 0;
}
